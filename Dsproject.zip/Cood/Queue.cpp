#include "Queue.h"
using namespace std;

template<typename T>
Queue<T>::Queue() : frontIndex(0) {}

template<typename T>
void Queue<T>::enqueue(const T& element) {
    vec.push_back(element);
}

template<typename T>
T Queue<T>::dequeue() {
    if (isEmpty()) {
        cout << "Queue is empty!\n";
        return T();
    }
    T frontElement = vec[frontIndex];
    ++frontIndex;

    if (frontIndex == vec.getSize()) {
        vec = Vector<T>();
        frontIndex = 0;
    }

    return frontElement;
}


template<typename T>
T Queue<T>::front() const {
    if (isEmpty()) {
        cout << "Queue is empty!\n";
        return T();
    }
    return vec[frontIndex];
}

template<typename T>
bool Queue<T>::isEmpty() const {
    return frontIndex == vec.getSize();
}

template<typename T>
int Queue<T>::getSize() const {
    return vec.getSize() - frontIndex;
}