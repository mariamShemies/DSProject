#pragma
#ifndef USER_H
#define USER_H

#include <string>
#include "PriorityQueue.h"
#include "Vector.h"

using namespace std;

class User {
public:
    string name;
    string username;
    string email;
    bool admin;
    User* next;
   
    User();
    User(const string& u, const string& n, const string& e, bool isAdmin = false);
    void setAdmin(bool admin);
    void display();
    
    friend ostream& operator<<(ostream& os, const User& user) {
        os << "Name: " << user.name
            << ", Username: " << user.username
            << ", Email: " << user.email;
        return os;
    }

};


#endif // USER_H

