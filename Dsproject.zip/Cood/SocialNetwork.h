#pragma once
#include <iostream>
#include <string>
#include "Graph.h"
#include "PriorityQueue.h"
#include"HashTable.h"
#include "User.h"
#include "Vector.h"
using namespace std;

class SocialNetwork
{
    
private:
    Graph<string> socialNetwork;
    HashTable<string, User> users;
    int mutaulConnectionCount(const string& username1, const string& username2);
public:
    bool addUser(const string& username, const string& name, const string& email, bool isAdmin);
    bool removeUser(const string& username);
    User* findUser(const string& username);
    void listAllUsers();
    void updateUser(const string& username, const string& name, const string& email);
    bool addFriend(const string& username1, const string& username2);
    bool removeFriend(const string& username1, const string& username2);
    void listAllFriends(const string& username);
    User* findFriend(const string& username1, const string& username2);
    Vector<string> suggestFriends(const string& username);
    void print();
    User* searchForUser(string username);
};

