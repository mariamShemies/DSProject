#include "SocialNetwork.h"
#include "Graph.cpp"
#include "HashTable.cpp"
#include "Vector.cpp"
#include "PriorityQueue.cpp"
#include "Queue.cpp"

bool SocialNetwork::addUser(const string& username, const string& name, const string& email, bool isAdmin) {
	User user(username, name, email, isAdmin);
	user.admin = isAdmin;
	users.insert(username, user);
	return socialNetwork.addVertex(username);
}

bool SocialNetwork::removeUser(const string& username) {
	users.remove(username);
	return socialNetwork.removeVertex(username);
}

User* SocialNetwork::findUser(const string& username) {
	return socialNetwork.hasVertex(username) ? users[username] : nullptr;
}
void SocialNetwork::listAllUsers() {
	users.print();
}
void SocialNetwork::updateUser(const string& username, const string& name, const string& email) {
	User* user = findUser(username);
	if (user == nullptr) {
		cout << "There is nn User with that username \n";
	}
	else {
		user->name = name;
		user->email=email;
	}
}

bool SocialNetwork::addFriend(const string& username1, const string& username2){
	return socialNetwork.addEdge(username1, username2);
}

bool SocialNetwork::removeFriend(const string& username1, const string& username2) {
	return socialNetwork.removeEdge(username1, username2);
}

void SocialNetwork::listAllFriends(const string& username) {
	Vector<std::string>* friends = socialNetwork.getNeighbors(username);
	if (friends->isEmpty()) {
		std::cout << "You have no friends yet.\n";
	}
	else {
		friends->print();
	}
}

User* SocialNetwork::  findFriend(const string& username1, const string& username2) {
	Vector <string>* temp =socialNetwork.getNeighbors(username1);
	for (int i = 0; i < temp->getSize(); i++)
	{
		if ((*temp)[i] == username2)
		{
			return users[username2];
		}
	}
	cout << "There is no friend with that Username \n";
}

Vector<string> SocialNetwork::suggestFriends(const string& username) {
	Vector<string> suggestions;
	PriorityQueue<pqNode> potentialFriends;
	Queue<string> q;
	HashTable<string, bool> processed;
	processed.insert(username, true);

	Vector<string>* friends = socialNetwork.getNeighbors(username);
	if (!friends) {
		return suggestions;
	}

	for (int i = 0; i < friends->getSize(); i++) {
		processed.insert((*friends)[i], true);
		q.enqueue((*friends)[i]);
	}

	while (!q.isEmpty()) {
		string currentUser = q.front();
		q.dequeue();

		Vector<string>* friendsOfFriend = socialNetwork.getNeighbors(currentUser);
		if (!friendsOfFriend) continue;

		for (int i = 0; i < friendsOfFriend->getSize(); i++) {
			string potential = (*friendsOfFriend)[i];
			if (processed[potential] != nullptr) continue;

			processed.insert(potential, true);
			int level = socialNetwork.bfsDistances(username, potential);
			int mutualCount = mutaulConnectionCount(username, potential);

			potentialFriends.insert(pqNode(level, mutualCount, potential));
			q.enqueue(potential);
		}
	}

	while (!potentialFriends.isEmpty()) {
		pqNode suggestion = potentialFriends.extractTop();
		suggestions.push_back(suggestion.name);
	}

	return suggestions;
}


int SocialNetwork::mutaulConnectionCount(const string& username1, const string& username2){
	if (!(socialNetwork.hasVertex(username1)&&socialNetwork.hasVertex(username2)))
	{
		return -1;
	}
	int count = 0;
	Vector<string>* temp1 = socialNetwork.getNeighbors(username1);
	Vector<string>* temp2 = socialNetwork.getNeighbors(username2);
	if (!temp1||!temp2)
	{
		return 0;
	}
	for (int i = 0; i < temp1->getSize(); i++)
	{
		for (int j = 0; j < temp2->getSize(); j++)
		{
			if ((*temp1)[i]==(*temp2)[j])
			{
				count++;
			}
		}
	}
	return count;
}

User* SocialNetwork::searchForUser(string username) {
	return socialNetwork.hasVertex(username) ? users[username] : nullptr;
}

void SocialNetwork::print() {
	socialNetwork.print();
}