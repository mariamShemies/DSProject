#pragma once
#include "Vector.h"

template<typename T>
class Queue {
private:
    Vector<T> vec;
    int frontIndex;

public:
    Queue();
    void enqueue(const T& element);
    T dequeue();
    T front() const;
    bool isEmpty() const;
    int getSize() const;
};