#pragma once
#include <iostream>
#include <string>
#include <functional>
using namespace std;

const int hashTableSize = 100;

template <typename KeyType, typename ValueType>
class HashNode {
public:
    KeyType key;
    ValueType value;
    HashNode* next;

    HashNode() : key(KeyType()), value(ValueType()), next(nullptr) {}
    HashNode(KeyType k, ValueType v) : key(k), value(v), next(nullptr) {}
    HashNode(const HashNode& other) : key(other.key), value(other.value), next(other.next) {}

  /*  bool operator==(const HashNode& other) const {
        return value == other.value;
    }

    bool operator!=(const HashNode& other) const {
        return value != other.value;
    }*/

    friend std::ostream& operator<<(std::ostream& os, const HashNode<KeyType, ValueType>& node) {
        os << "[" << node.key << ": " << node.value << "]";
        return os;
    }
};



template <typename KeyType, typename ValueType>
class HashTable {
private:
    HashNode<KeyType, ValueType>* hashTable[hashTableSize];
    int numOfElements;

    int hashCode(KeyType key);

public:
    HashTable();
    ~HashTable();

    void insert(KeyType key, ValueType value);
    void remove(KeyType key);
    ValueType* operator[](KeyType key);
    bool operator==(const HashTable<KeyType, ValueType>& other) const;
    bool isEmpty();
    void empty();
    void print();
    HashNode<KeyType, ValueType>* atIndex(int index);

};
