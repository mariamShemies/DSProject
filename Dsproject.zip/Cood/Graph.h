#pragma once
#include "HashTable.h"
#include "Vector.h"
#include "PriorityQueue.h"
#include "Queue.h"
using namespace std;

template<typename T>
class Graph {
private:
    mutable HashTable<T, Vector<T>> adjList;
	int numOfVertices;

public:
    Graph();
    bool hasVertex(const T& vertex)const;
    bool addVertex(const T& vertex);
    bool addEdge(const T& vertex1, const T& vertex2);
    bool removeVertex(const T& vertex);
    bool removeEdge(const T& vertex1, const T& vertex2);
    Vector<T>* getNeighbors(const T& vertex) const;
    int bfsDistances(const T& startNode,const T& endNode)const  ;
    void print();
};
