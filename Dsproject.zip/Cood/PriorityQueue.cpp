#include "PriorityQueue.h"

template <typename T>
PriorityQueue<T>::PriorityQueue(int initialCapacity){
    capacity = initialCapacity;
    heap = new T[capacity];
    size = 0;
}
    


template <typename T>
PriorityQueue<T>::~PriorityQueue() {
    delete[] heap;
}

template <typename T>
void PriorityQueue<T>::resize() {
    capacity *= 2;
    T* newHeap = new T[capacity];
    for (int i = 0; i < size; ++i) {
        newHeap[i] = heap[i];
    }
    delete[] heap;
    heap = newHeap;
}

template <typename T>
void PriorityQueue<T>::heapify(int index) {
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    int largest = index;

    if (left < size && heap[left] > heap[largest]) {
        largest = left;
    }

    if (right < size && heap[right] > heap[largest]) {
        largest = right;
    }

    if (largest != index) {
        swap(heap[index], heap[largest]);
        heapify(largest);
    }
}

template <typename T>
void PriorityQueue<T>::insert(const T& element) {
    if (size == capacity) {
        resize();
    }

    heap[size] = element;
    int index = size;
    ++size;

    while (index > 0) {
        int parent = (index - 1) / 2;
        if (heap[index] > heap[parent]) {
            swap(heap[index], heap[parent]);
            index = parent;
        }
        else {
            break;
        }
    }
}


template <typename T>
T PriorityQueue<T>::extractTop() {
    if (isEmpty()) {
        cout << "Priority queue is empty" << endl;
        exit(0);
    }

    T top = heap[0];
    heap[0] = heap[size - 1];
    --size;
    heapify(0);
    return top;
}

template <typename T>
T PriorityQueue<T>::peek() const {
    if (isEmpty()) {
        cout << "Priority queue is empty" << endl;
        exit(0);
    }
    return heap[0];
}

template <typename T>
bool PriorityQueue<T>::isEmpty() const {
    return size == 0;
}

template <typename T>
int PriorityQueue<T>::getSize() const {
    return size;
}
