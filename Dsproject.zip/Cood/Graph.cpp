#include "Graph.h"
using namespace std;



template <typename T>
Graph<T>::Graph(){
    numOfVertices = 0;
}
template <typename T>
bool Graph<T>::hasVertex(const T& vertex) const {
    return adjList[vertex] != nullptr;
}

template <typename T>
bool Graph<T>::addVertex(const T& vertex) {
    if (!hasVertex(vertex)) {
        Vector<T> neighbors;
        adjList.insert(vertex, neighbors);
        return true;
    }
    else {
        return false;
    }
}

template <typename T>
bool Graph<T>::addEdge(const T& vertex1, const T& vertex2) {
    if (!(hasVertex(vertex1) && hasVertex(vertex2))) {
        return false;
    }
    else {
        if (adjList[vertex1]->find(vertex2)) {
            return false;
        }
        else {
            adjList[vertex1]->push_back((vertex2));
            adjList[vertex2]->push_back((vertex1));
            return true;
        }
    }
}

template <typename T>
bool Graph<T>::removeVertex(const T& vertex) {
    if (!hasVertex(vertex)) {
        return false;
    }
    Vector<T>* temp = getNeighbors(vertex);

 
    for (int i = 0; i < temp->getSize(); i++) {
        adjList[(*temp)[i]]->remove(vertex);
    }
    adjList.remove(vertex);
    return true;
}

template <typename T>
bool Graph<T>::removeEdge(const T& vertex1, const T& vertex2) {
    if (!(adjList[vertex1]->find(vertex2))) {
        return false;
    }
    else if (hasVertex(vertex1) && hasVertex(vertex2)) {
        adjList[vertex1]->remove((vertex2));
        adjList[vertex2]->remove((vertex1));
        return true;
    }
    else {
        return false;
    }
    return false;
}

template <typename T>
Vector<T>* Graph<T>::getNeighbors(const T& vertex)const {
    return adjList[vertex];
}

template <typename T>
void Graph<T>::print() {
    for (int i = 0; i < hashTableSize; i++) {
        if (adjList.atIndex(i) != NULL) {
            HashNode<string, Vector<T>>* temp(adjList.atIndex(i));
            while (temp != nullptr) {
                cout << temp->key << " -> ";
                getNeighbors(temp->key)->print();
                cout << endl;
                temp = temp->next;
            }

        }
    }
}

template <typename T>
int Graph<T>::bfsDistances(const T& startNode, const T& endNode) const {
    if (!(hasVertex(startNode) && hasVertex(endNode))) {
        return -1;
    }

    Queue<T> q;
    HashTable<T, int> distances;
    Vector<T> visited;

    q.enqueue(startNode);
    distances.insert(startNode, 0);
    visited.push_back(startNode);

    while (!q.isEmpty()) {
        T currentNode = q.front();
        q.dequeue();

        if (currentNode == endNode) {
            return *(distances[currentNode]);
        }

        Vector<T>* neighbors = getNeighbors(currentNode);

        for (int i = 0; i < neighbors->getSize(); i++) {
            T neighbor = (*neighbors)[i];

            if (!(visited.find(neighbor))) {
                visited.push_back(neighbor);
                distances.insert(neighbor, *(distances[currentNode]) + 1);
                q.enqueue(neighbor);
            }
        }
    }

    return -1;
}

