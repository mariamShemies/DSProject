#include <iostream>
#include "Vector.cpp"
#include "HashTable.cpp"
#include "PriorityQueue.cpp"
#include "Queue.cpp"
#include "Graph.cpp"
#include "User.h"
#include "SocialNetwork.h"
using namespace std;

void displayMenu(User* loginUser);
void displayMenuAdmin(User* loginUser);

SocialNetwork network;
User admin("Admin", "Admin", "Admin@gmail.com", true);

void pause(const string& message = "Press Enter to continue...") {

    cout << message << endl;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

int main()
{
    admin.setAdmin(true);
    network.addUser(admin.username, admin.name, admin.email, true);
    while (true)
    {
        system("cls");
        cout << "1- Register\n" << "2- Login\n" << "3- Exit\n" ;
        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1)
        {
            string username, name, email;
            cout << "Username : ";
            cin >> username;
            cout << "Name : ";
            cin >> name;
            cout << "Email : ";
            cin >> email;
            cin.ignore();
            network.addUser(username, name, email, false);
            choice = 2;
        }

        else if (choice == 2)
        {
            User* user;
            cout << "Please enter your user name to Login:\n";
            string username;
            cin >> username;
            cin.ignore();
            if (network.findUser(username))
            {
                user = network.searchForUser(username);
                if (user->admin) {
                    displayMenuAdmin(user);
                }
                else {
                    displayMenu(user);
                }
            }
            else
            {
                cout << "Please register first\n";
                continue;
            }
        }
        else if (choice == 3)
        {
            exit(0);
        }
        else {
            main();
            continue;
        }
    }
    return 0;
}

void displayMenu(User* loginUser)
{
    while (true)
    {
        system("cls");
        cout << "Hello " << loginUser->name << endl << endl;
        cout << "1- List all friends\n" << "2- Search by User name\n" << "3- Add friend\n" << "4- Remove friend\n" <<
             "5- People you may know\n" << "6- logout\n";
        int choice;
        cin >> choice;

        if (choice == 1)
        {
            cout << "Your Friends" << endl << "-------------" << endl;
            network.listAllFriends(loginUser->username);
            cout << endl;
            pause();
        }

        else if (choice == 2)
        {
            cout << "Please enter the user name you are searching for\n";
            string username;
            cin >> username;
            User* foundUser;
            if (network.findUser(username))
            {
                foundUser = network.searchForUser(username);
            }

            else
            {
                foundUser = NULL;
            }

            if (foundUser != NULL)
            {
                cout << foundUser->username << ", " << foundUser->name << ", " << foundUser->email << endl;
            }
            else
            {
                cout << "NOT Found\n";
            }
            pause();
        }

        else if (choice == 3)
        {
            cout << "Please enter the user name of the new friend\n";
            string username;
            cin >> username;

            if (!network.findUser(username)) {
                cout << "this user is not in the system\n";
                continue;
            }
            else if (network.addFriend(loginUser->username, username))
            {
                cout << "You are now friends!!\n";
            }
            else
            {
                cout << "You are already friends!\n";;
            }
            pause();
        }

        else if (choice == 4)
        {

            cout << "Please enter the user What you want to delete\n";
            string username;
            cin >> username;

            if (network.removeFriend(username, loginUser->username)) {
                cout << "Deleted friend Successful!" << endl;
            }
            else cout << "This friend's not in your friends." << endl;
            pause();
        }

        else if (choice == 5)
        {
            cout << "People you may know" << endl << "--------------------" << endl;
            network.suggestFriends(loginUser->username).print();
            cout << endl << endl;
            pause();
        }

        else if (choice == 6)
        {
            break;
        }
    }
}

void displayMenuAdmin(User* loginUser)
{ 
    while (true)
    {
        system("cls");
        cout << "Hello " << loginUser->name << endl << endl;
        cout << "1- Remove User\n" << "2- Update User\n" << "3- List all Users\n" << "4- logout\n";
        int choice;
        cin >> choice;

        if (choice == 1)
        {
            cout << "Enter attributes of user you want to delete:\n";
            string username;
            cout << "Username: ";
            cin >> username;
            network.removeUser(username);
            cout << "User removed successfully!\n";
            pause();;
        }

        else if (choice == 2)
        {
            cout << "Enter attributes of user you want to update:\n";
            string username;
            cout << "Username: ";
            cin >> username;
            string name;
            cout << "Name: ";
            cin >> name;
            string email;
            cout << "Email: ";
            cin >> email;
            network.updateUser(username, name, email);
            cout << "User updated successfully!\n";
            pause();
        }

        else if (choice == 3)
        {
            network.print();
            cout << endl;
            pause();
        }
        else if (choice == 4)
        {
            break;
        }
    }
}
