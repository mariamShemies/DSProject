#include "User.h"
void User::display() {
	cout << "Name: " << this->name << "\nUsername: " << this->username << "\nEmail: " << this->email;

}
User::User() {}
User::User(const string& u, const string& n, const string& e, bool isAdmin) {
	this->username = u;
	this->name = n;
	this->email = e;
	this->admin = isAdmin;
}

void User::setAdmin(bool admin) {
	this->admin = admin;
}
