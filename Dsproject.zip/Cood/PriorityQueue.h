#pragma once
#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H

#include <string>
#include <iostream>
using namespace std;

struct pqNode {
    int key1;
    int key2;
    string name;

    pqNode() {
        key1 = 0;
        key2 = 0;
        name = "Unknown";
    }
    pqNode(int key1, int key2, string name)
        : key1(key1), key2(key2), name(name) {
    }
    bool operator<(const pqNode& other) const {
        if (key1 == other.key1) {
            return key2 < other.key2;
        }
        return key1 > other.key1;
    }

    bool operator>(const pqNode& other) const {
        if (key1 == other.key1) {
            return key2 > other.key2;
        }
        return key1 < other.key1;
    }
};


template <typename T>
class PriorityQueue {
private:
    T* heap;
    int capacity;
    int size;


    void heapify(int index);
    void resize();

public:
    PriorityQueue(int initialCapacity = 10);
    ~PriorityQueue();

    void insert(const T& element);
    T extractTop();
    T peek() const;
    bool isEmpty() const;
    int getSize() const;
};

#endif

