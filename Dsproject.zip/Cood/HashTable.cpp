#include "HashTable.h"
using namespace std;

#include <sstream>

template <typename KeyType, typename ValueType>
int HashTable<KeyType, ValueType>::hashCode(KeyType key) {
    int asciiSum = 0;
    try {
       ostringstream oss;
        oss << key;
       string string_key = oss.str();

        for (char ch : string_key) {
            asciiSum += (int)(ch);
        }
    }
    catch (...) {
       cerr << "Error: KeyType cannot be converted to a string. \n";
        throw;
    }
    return asciiSum % hashTableSize;
}


template <typename KeyType, typename ValueType>
HashTable<KeyType, ValueType>::HashTable() {
    numOfElements = 0;
    for (int i = 0; i < hashTableSize; ++i) {
        hashTable[i] = nullptr;
    }
}

template <typename KeyType, typename ValueType>
HashTable<KeyType, ValueType>::~HashTable() {
    empty();
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::operator==(const HashTable<KeyType, ValueType>& other) const {
    if (this->numOfElements != other.numOfElements) {
        return false;
    }

    for (int i = 0; i < this->hashTableSize; ++i) {
        HashNode<KeyType, ValueType>* thisNode = this->hashTable[i];
        HashNode<KeyType, ValueType>* otherNode = other.hashTable[i];

        while (thisNode != nullptr && otherNode != nullptr) {
            if (*(thisNode->key) != *(otherNode->key) || *(thisNode->value) != *(otherNode->value)) {
                return false;
            }
            thisNode = thisNode->next;
            otherNode = otherNode->next;
        }

        if (thisNode != nullptr || otherNode != nullptr) {
            return false;
        }
    }

    return true;
}

template <typename KeyType, typename ValueType>
void HashTable<KeyType, ValueType>::insert(KeyType key, ValueType value) {
    HashNode<KeyType, ValueType>* newNode = new HashNode<KeyType, ValueType>(key, value);

    int index = hashCode(key);

    if (hashTable[index] == nullptr) {
        hashTable[index] = newNode;
        numOfElements++;
    }
    else {
        HashNode<KeyType, ValueType>* temp = hashTable[index];
        while (temp->next != nullptr && temp->key != key) {
            temp = temp->next;
        }

        if (temp->key == key) {
            delete newNode;  // Key already exists, delete new node
            cout << "The key " << key << " already exists.\n";
        }
        else {
            temp->next = newNode;  // Insert new node at the end of the chain
            numOfElements++;
        }
    }
}


template <typename KeyType, typename ValueType>
void HashTable<KeyType, ValueType>::remove(KeyType key) {
    int index = hashCode(key);
    if (!hashTable[index]) {
        cout << "Key " << key << " not found in hash table.\n";
        return;
    }

    HashNode<KeyType, ValueType>* temp = hashTable[index];
    if (temp->key == key) {
        hashTable[index] = temp->next;
        delete temp;
        numOfElements--;
        return;
    }

    HashNode<KeyType, ValueType>* prev = nullptr;
    while (temp != nullptr && temp->key != key) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Key " << key << " not found in hash table.\n";
        return;
    }

    prev->next = temp->next;
    delete temp;
    numOfElements--;
}

template <typename KeyType, typename ValueType>
ValueType* HashTable<KeyType, ValueType>::operator[](KeyType key) {
    int index = hashCode(key);
    HashNode<KeyType, ValueType>* temp = hashTable[index];
    while (temp != nullptr) {
        if (temp->key == key) {
            return &(temp->value);
        }
        temp = temp->next;
    }
    return nullptr;
}

template <typename KeyType, typename ValueType>
bool HashTable<KeyType, ValueType>::isEmpty() {
    return numOfElements == 0;
}

template <typename KeyType, typename ValueType>
void HashTable<KeyType, ValueType>::empty() {
    for (int i = 0; i < hashTableSize; i++) {
        while (hashTable[i] != nullptr) {
            HashNode<KeyType, ValueType>* temp = hashTable[i];
            hashTable[i] = temp->next;
            delete temp;
        }
    }
    numOfElements = 0;
}

template <typename KeyType, typename ValueType>
void HashTable<KeyType, ValueType>::print() {
    if (!isEmpty()) {
        for (int i = 0; i < hashTableSize; i++) {
            if (hashTable[i] != nullptr) {
                cout << i << ": ";
                HashNode<KeyType, ValueType>* temp = hashTable[i];
                while (temp != nullptr) {
                    cout << *temp << " -> ";
                    temp = temp->next;
                }
                cout << "NULL\n";
            }
        }
    }
    else {
        cout << "The Hashtable is empty \n";
    }
}
template <typename KeyType, typename ValueType>
HashNode<KeyType, ValueType>* HashTable<KeyType, ValueType>::atIndex(int index) {
    if (hashTable[index] == nullptr) {
        return nullptr;
    }
    return (hashTable[index]); 
}

