#include "Vector.h"

template<typename T>
Vector<T>::Vector(int inCapacity) : capacity(inCapacity), size(0) {
    data = new T[capacity];
}

template<typename T>
Vector<T>::Vector(const Vector& other)
    : capacity(other.capacity), size(other.size), data(nullptr) {
    if (capacity > 0) {
        data = new T[capacity];
        for (int i = 0; i < size; ++i) {
            data[i] = other.data[i];
        }
    }
}


template<typename T>
Vector<T>& Vector<T>::operator=(const Vector& other) {
    if (this == &other) {
        return *this;
    }

    delete[] data;

    capacity = other.capacity;
    size = other.size;
    data = new T[capacity];
    for (int i = 0; i < size; ++i) {
        data[i] = other.data[i];
    }

    return *this;
}

template<typename T>
Vector<T>::~Vector() {
    delete[] data;
}

template<typename T>
void Vector<T>::resize() {
    if (size >= capacity) {
        capacity *= 2;
        T* newData = new T[capacity];
        for (int i = 0; i < size; ++i) {
            newData[i] = data[i];
        }
        delete[] data;
        data = newData;
    }
}

template<typename T>
void Vector<T>::push_back(const T& element) {
    resize();              
    data[size++] = element; 
}



template<typename T>
T Vector<T>::pop_back() {
    if (isEmpty()) {
        cout << "Vector is empty!\n";
        return T();
    }
    return data[--size];
}

template<typename T>
void Vector<T>::remove(const T& element) {
    bool found = false;
    for (int i = 0; i < size; ++i) {
        if (data[i] == element) {
            found = true;
            for (int j = i; j < size - 1; ++j) {
                data[j] = data[j + 1]; 
            }
            --size; 
            break; 
        }
    }

    if (!found) {
        cerr << "The element is not in the vector.\n";
    }
}

template<typename T>
void Vector<T>::insert(int index, const T& element) {
    if (index < 0 || index > size) {
        cout << "Index Out Of Bounds!\n";
        return;
    }
    resize();
    for (int i = size; i > index; --i) {
        data[i] = data[i - 1];
    }
    data[index] = element;
    ++size;
}

template<typename T>
T Vector<T>::operator[](int index) const {
    if (index < 0 || index >= size) {
        cout << "Index Out Of Bounds!\n";
        return T();
    }
    return data[index];
}

template<typename T>
int Vector<T>::getSize() const {
    return size;
}

template<typename T>
int Vector<T>::getCapacity() const {
    return capacity;
}

template<typename T>
bool Vector<T>::isEmpty() const {
    return size == 0;
}
template<typename T>
void Vector<T>::print() const {
    for (int i = 0; i < this->size; i++)
    {
        cout << data[i];
        if (i!=(this->size-1))
        {
            cout << " - ";
        }
    }
} 
template<typename T>
bool Vector<T>::find(const T& element) const {
    for (int i = 0; i < size; i++)
    {
        if (element == data[i])
        {
            return true;
        }
    }
    return false;
}