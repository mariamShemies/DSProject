#pragma once
#include <iostream>
using namespace std;

template<typename T>
class Vector {
private:
    T* data;
    int size;
    int capacity;

    void resize();

public:
    Vector(int inCapacity = 10);
    Vector(const Vector& other);
    Vector& operator=(const Vector& other);
    ~Vector();

    void push_back(const T& element);
    T pop_back();
    void remove(const T& element);
    void insert(int index, const T& element);
    T operator[](int index) const;
    int getSize() const;
    int getCapacity() const;
    bool isEmpty() const;
    void print() const;
    bool find(const T& element) const;
};